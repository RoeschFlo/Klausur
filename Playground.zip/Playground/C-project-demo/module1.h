#ifndef MODULE1_H_INCLUDED
#define MODULE1_H_INCLUDED

#define MODULE1_NAME "module1"

int function1(void) ;

#endif // MODULE1_H_INCLUDED
